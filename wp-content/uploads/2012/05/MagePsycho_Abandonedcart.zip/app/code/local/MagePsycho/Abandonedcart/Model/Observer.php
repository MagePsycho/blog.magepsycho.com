<?php
/**
 * @category   MagePsycho
 * @package    MagePsycho_Abandonedcart
 * @author     magepsycho@gmail.com
 * @website    http://www.magepsycho.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class MagePsycho_Abandonedcart_Model_Observer
{
	public function clearAbandonedCarts(Varien_Event_Observer $observer)
	{
		$lastQuoteId = Mage::getSingleton('checkout/session')->getQuoteId();
        if ($lastQuoteId) {
            $customerQuote = Mage::getModel('sales/quote')
                ->loadByCustomer(Mage::getSingleton('customer/session')->getCustomerId());
            $customerQuote->setQuoteId($lastQuoteId);
            $this->_removeAllItems($customerQuote);

        } else {
            $quote = Mage::getModel('checkout/session')->getQuote();
            $this->_removeAllItems($quote);
        }
	}

	protected function _removeAllItems($quote){
        foreach ($quote->getAllItems() as $item) {
            $item->isDeleted(true);
            if ($item->getHasChildren()) {
				foreach ($item->getChildren() as $child) {
					$child->isDeleted(true);
				}
			}
        }
        $quote->collectTotals()->save();
    }
}