<?php
/**
 * @category   MagePsycho
 * @package    MagePsycho_Abandonedcart
 * @author     magepsycho@gmail.com
 * @website    http://www.magepsycho.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class MagePsycho_Abandonedcart_Block_Abandonedcart extends Mage_Core_Block_Template
{

}