#!/bin/bash
#@author		MagePsycho <magepsycho@gmail.com>
#@website		http://www.magepsycho.com
#@version		0.1.0

#/************************ EDIT VARIABLES ************************/
projectName=magepsycho
backupDir=/home/secretsf/_backups
#/************************ //EDIT VARIABLES **********************/

dbXmlPath="app/etc/local.xml"
{
	# the given XML is in file.xml
	host="$(echo "cat /config/global/resources/default_setup/connection/host/text()" | xmllint --nocdata --shell $dbXmlPath | sed '1d;$d')"
	username="$(echo "cat /config/global/resources/default_setup/connection/username/text()" | xmllint --nocdata --shell $dbXmlPath | sed '1d;$d')"
	password="$(echo "cat /config/global/resources/default_setup/connection/password/text()" | xmllint --nocdata --shell $dbXmlPath | sed '1d;$d')"
	dbName="$(echo "cat /config/global/resources/default_setup/connection/dbname/text()" | xmllint --nocdata --shell $dbXmlPath | sed '1d;$d')"
	#printf '%s\n' "host: $host" "username: $username" "password: $password" "dbName: $dbName"
}

fileName=$projectName-$(date +"%Y-%m-%d")
printf "What kind of backup you would like?\n[ d ] DB backup only\n[ f ] Files backup only\n[ b ] Files backup with DB\n"
read backupType
if [[ $backupType = @(d|b) ]]; then
	echo "----------------------------------------------------"
	echo "Dumping MySQL..."
	mysqldump -h $host -u $username -p$password $dbName > $fileName.sql
	echo "Done!"
fi

if [[ $backupType = @(f|b) ]]; then
	echo "----------------------------------------------------"
	echo "Archiving Files..."
	printf "Skip /media folder?\ny: Yes\nn: No\n"
	read skipMedia
	if [ $skipMedia == y ]; then
		tar -zcf $fileName.tar.gz --exclude=var --exclude=includes --exclude=media * .htaccess
	else
		tar -zcf $fileName.tar.gz --exclude=var --exclude=includes * .htaccess
	fi
	echo "Done!"
	echo "----------------------------------------------------"
	echo "Cleaning..."
	rm -f $fileName.sql
	echo "Done!"
fi

if [[ $backupType = @(d|f|b) ]]; then
	echo "----------------------------------------------------"
	mkdir -p $backupDir;
	echo "Moving file to backup dir..."
	if [ $backupType == d ]; then
		mv $fileName.sql $backupDir
	fi

	if [[ $backupType = @(f|b) ]]; then
		mv $fileName.tar.gz $backupDir
	fi
	echo "Done!"
else
	echo "Invalid selection!"
fi